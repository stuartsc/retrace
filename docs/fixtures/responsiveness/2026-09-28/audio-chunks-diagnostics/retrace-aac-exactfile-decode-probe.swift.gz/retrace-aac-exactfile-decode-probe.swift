import AVFoundation
import CryptoKit
import Foundation
let dir = FileManager.default.temporaryDirectory.appendingPathComponent("retrace-aac-repeat-\(UUID())")
try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
let url = URL(fileURLWithPath:"/var/folders/lc/bzv28_2x2jl5vpt7tj8vksmm0000gn/T/audio-chunk-test-AB0B4C08-F433-4409-A334-210EFAC13F35/audio/chunk-media/2693d69b-5738-4104-a877-b24563aa40b2/f72692c2-2a88-448d-b006-380787a693e8.m4a")
func sha(_ d:Data)->String { SHA256.hash(data:d).map{String(format:"%02x",$0)}.joined() }
func encode() throws {
 let format = AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:16000,channels:1,interleaved:false)!
 let buffer = AVAudioPCMBuffer(pcmFormat:format,frameCapacity:16000)!
 buffer.frameLength=16000
 for i in 0..<16000 { buffer.floatChannelData![0][i]=Float(sin(Double(i)*0.13)*0.3) }
 let settings:[String:Any]=[AVFormatIDKey:kAudioFormatMPEG4AAC,AVSampleRateKey:16000.0,AVNumberOfChannelsKey:1,AVEncoderAudioQualityKey:AVAudioQuality.medium.rawValue]
 let file=try AVAudioFile(forWriting:url,settings:settings,commonFormat:.pcmFormatFloat32,interleaved:false)
 try file.write(from:buffer)
}
func decode(_ format:AVAudioCommonFormat) throws -> Data {
 let file=try AVAudioFile(forReading:url,commonFormat:format,interleaved:true)
 let buffer=AVAudioPCMBuffer(pcmFormat:file.processingFormat,frameCapacity:4096)!
 var output=Data()
 var remaining=file.length
 while remaining>0 {
  try file.read(into:buffer,frameCount:AVAudioFrameCount(min(4096,remaining)))
  let count=Int(buffer.frameLength)
  if format == .pcmFormatInt16 { output.append(Data(bytes:buffer.int16ChannelData![0],count:count*2)) }
  else { output.append(Data(bytes:buffer.floatChannelData![0],count:count*4)) }
  remaining -= Int64(count)
 }
 return output
}

for format in [AVAudioCommonFormat.pcmFormatInt16,.pcmFormatFloat32] {
 var previous:Data?
 for iteration in 1...5 {
  let data=try decode(format)
  if iteration == 1 { try data.write(to:URL(fileURLWithPath:"/tmp/retrace-aac-probe-format-\(format.rawValue).pcm")) }
  let differing=previous.map { prior in zip(prior,data).filter{$0 != $1}.count } ?? 0
  print("format \(format.rawValue) iteration \(iteration) hash \(sha(data)) differingBytes \(differing)")
  previous=data
 }
}
try FileManager.default.removeItem(at:dir)
