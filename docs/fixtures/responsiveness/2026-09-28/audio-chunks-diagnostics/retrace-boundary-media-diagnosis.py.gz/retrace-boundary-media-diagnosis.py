from pathlib import Path
import json, subprocess, wave, array, math, hashlib, struct
root=Path('/tmp/retrace-audio-boundary-final-20260928-1749')
out=Path('/tmp/retrace-boundary-media-diagnosis-20260928-1755-v2')
out.mkdir(exist_ok=False)
original=Path('/Users/stuartbond/backintime/Processing/Tests/Fixtures/WhisperTimedWords/authored.wav')
def read_wave(path):
    blob=path.read_bytes()
    assert blob[:4]==b'RIFF' and blob[8:12]==b'WAVE'
    cursor=12; fmt=None; data=None
    while cursor+8<=len(blob):
        key=blob[cursor:cursor+4]; size=struct.unpack_from('<I',blob,cursor+4)[0]
        chunk=blob[cursor+8:cursor+8+size]
        if key==b'fmt ':
            tag,ch,rate=struct.unpack_from('<HHI',chunk)
            bits=struct.unpack_from('<H',chunk,14)[0]
            assert tag in (1,65534) and bits==16
            fmt=[ch,bits//8,rate]
        if key==b'data': data=chunk
        cursor+=8+size+(size%2)
    assert fmt==[1,2,16000] and data is not None
    return fmt,data
with wave.open(str(original),'rb') as w:
    assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,16000)
    raw=w.readframes(w.getnframes())
assert hashlib.sha256(raw).hexdigest()=='b1295d561ac7a320eec47d9f5e5ccb58ed4e1e20f52dc3119b445f1d88952b41'
full=array.array('h',raw+raw)
items=[]
for receipt in (root/'chunked').rglob('chunk_*.json'):
    obj=json.loads(receipt.read_text())
    items.append(('candidate',root/'chunked'/obj['relativePath'],obj['startFrame'],obj['frameCount'],obj))
for index,path in enumerate(sorted((root/'legacy').rglob('*.m4a'))):
    items.append(('legacy',path,index*160000,[240000,183414][index],None))
rows=[]
for kind,path,start,count,receipt in items:
    destination=out/(kind+'_'+path.stem+'.wav')
    subprocess.run(['/usr/bin/afconvert',str(path),str(destination),'-f','WAVE','-d','LEI16'],check=True)
    fmt,b=read_wave(destination)
    samples=array.array('h',b)
    expected=full[start:start+count]
    n=min(len(samples),len(expected))
    e=sum(x*x for x in expected[:n]); a=sum(x*x for x in samples[:n]); dot=sum(x*y for x,y in zip(expected,samples)); noise=sum((x-y)**2 for x,y in zip(expected,samples))
    info=subprocess.check_output(['/usr/bin/afinfo',str(path)],text=True)
    (out/(kind+'_'+path.stem+'.afinfo.txt')).write_text(info)
    row={'arm':kind,'path':str(path.relative_to(root)),'start_frame':start,'expected_frames':count,'decoded_frames':len(samples),'format':fmt,'encoded_bytes':path.stat().st_size,'encoded_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'decoded_sha256':hashlib.sha256(b).hexdigest(),'expected_rms':math.sqrt(e/n),'decoded_rms':math.sqrt(a/n),'decoded_peak':max(abs(x) for x in samples),'correlation':dot/math.sqrt(e*a),'snr_db':10*math.log10(e/max(1,noise)),'original_pcm_receipt_matches':receipt is None or hashlib.sha256(expected.tobytes()).hexdigest()==receipt['originalPCMSHA256']}
    row['per_second']=[]
    for first in range(0,n,16000):
        x=expected[first:first+16000]; y=samples[first:first+16000]
        ex=sum(z*z for z in x); ey=sum(z*z for z in y); d=sum(u*v for u,v in zip(x,y)); err=sum((u-v)**2 for u,v in zip(x,y))
        row['per_second'].append({'second':first/16000,'correlation':d/math.sqrt(max(1,ex*ey)),'snr_db':10*math.log10(max(1,ex)/max(1,err))})
    rows.append(row)
report={'source':str(original),'source_sha256':hashlib.sha256(raw).hexdigest(),'decoder':'native /usr/bin/afconvert WAVE LEI16, same rate','rows':rows}
(out/'media-comparison.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
