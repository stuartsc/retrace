import lldb
import json
import hashlib
from pathlib import Path
seen=set()
def collect(frame, location, dictionary):
    remaining=frame.FindVariable('remaining').GetValueAsSigned(-1)
    samples=frame.FindVariable('samples')
    pointer=samples.GetChildMemberWithName('_rawValue').GetValueAsUnsigned(0)
    if pointer == 0:
        pointer=samples.GetValueAsUnsigned(0)
    callers='|'.join(frame.GetThread().GetFrameAtIndex(i).GetFunctionName() or '' for i in range(1,min(4,frame.GetThread().GetNumFrames())))
    stage='encode' if 'encodeChunk' in callers else 'verify'
    key=(stage,remaining)
    if remaining < 1 or remaining>16000 or pointer==0 or key in seen:
        return False
    seen.add(key)
    if stage=='encode' and remaining==16000:
        value=frame.EvaluateExpression('url.path').GetSummary()
        source=Path(json.loads(value))
        encoded=source.read_bytes()
        destination=Path('/tmp/retrace-aac-debug4-native-variation.m4a')
        destination.write_bytes(encoded)
        print('AAC_FIXTURE',str(destination),len(encoded),hashlib.sha256(encoded).hexdigest())
    error=lldb.SBError()
    size=min(4096,remaining)*4
    data=frame.GetThread().GetProcess().ReadMemory(pointer,size,error)
    print('FLOAT_CAPTURE',stage,remaining,hex(pointer),len(data),error.GetCString())
    if error.Success(): Path('/tmp/retrace-float-'+stage+'-'+str(remaining)+'.pcm').write_bytes(data)
    return False
