import array
import hashlib
import json
import math
from pathlib import Path
import struct
import lldb

ROOT = Path(__file__).parent
records = []

def on_full(frame, breakpoint_location, internal_dict):
    try:
        process = frame.GetThread().GetProcess()
        registers = {name: frame.FindRegister(name).GetValueAsUnsigned() for name in ('x0', 'x1', 'x2', 'x3')}
        count = registers['x3'] & 0xffffffff
        if not 0 < count <= 1000000:
            raise RuntimeError('Invalid native sample count ' + str(count))
        error = lldb.SBError()
        raw_params = process.ReadMemory(registers['x1'], 304, error)
        if error.Fail() or len(raw_params) != 304:
            raise RuntimeError('Parameter read failed: ' + str(error))
        raw_samples = process.ReadMemory(registers['x2'], count * 4, error)
        if error.Fail() or len(raw_samples) != count * 4:
            raise RuntimeError('Sample read failed: ' + str(error))
        floats = struct.unpack('<' + str(count) + 'f', raw_samples)
        if any(not math.isfinite(value) for value in floats):
            raise RuntimeError('Nonfinite native samples')
        shorts = [round(value * 32768) for value in floats]
        if any(value < -32768 or value > 32767 for value in shorts):
            raise RuntimeError('Samples outside normalized Int16 range')
        pcm = struct.pack('<' + str(count) + 'h', *shorts)
        index = len(records) + 1
        stem = 'native_call_' + str(index)
        (ROOT / (stem + '.f32')).write_bytes(raw_samples)
        (ROOT / (stem + '.pcm')).write_bytes(pcm)
        (ROOT / (stem + '.params')).write_bytes(raw_params)
        params = {}
        for offset, name in [(0,'strategy'),(4,'n_threads'),(8,'n_max_text_ctx'),(12,'offset_ms'),(16,'duration_ms'),(40,'max_len'),(48,'max_tokens'),(56,'audio_ctx'),(96,'prompt_n_tokens'),(144,'best_of'),(148,'beam_size')]:
            params[name] = struct.unpack_from('<i', raw_params, offset)[0]
        for offset, name in [(20,'translate'),(21,'no_context'),(22,'no_timestamps'),(23,'single_segment'),(24,'print_special'),(25,'print_progress'),(26,'print_realtime'),(27,'print_timestamps'),(28,'token_timestamps'),(44,'split_on_word'),(52,'debug_mode'),(60,'tdrz_enable'),(80,'carry_initial_prompt'),(112,'detect_language'),(113,'suppress_blank'),(114,'suppress_nst'),(268,'vad')]:
            params[name] = bool(raw_params[offset])
        for offset, name in [(32,'thold_pt'),(36,'thold_ptsum'),(116,'temperature'),(120,'max_initial_ts'),(124,'length_penalty'),(128,'temperature_inc'),(132,'entropy_thold'),(136,'logprob_thold'),(140,'no_speech_thold'),(152,'beam_patience'),(264,'grammar_penalty')]:
            params[name] = struct.unpack_from('<f', raw_params, offset)[0]
        for offset, name in [(64,'suppress_regex'),(72,'initial_prompt'),(104,'language'),(272,'vad_model_path')]:
            pointer = struct.unpack_from('<Q',raw_params,offset)[0]
            params[name] = process.ReadCStringFromMemory(pointer,1024,error) if pointer else None
        for offset, name in [(160,'new_segment_callback'),(176,'progress_callback'),(192,'encoder_begin_callback'),(208,'abort_callback'),(224,'logits_filter_callback'),(240,'grammar_rules')]:
            params[name] = bool(struct.unpack_from('<Q',raw_params,offset)[0])
        record = {'index':index, 'frame_count':count,'float32_sha256':hashlib.sha256(raw_samples).hexdigest(),'reconstructed_int16_sha256':hashlib.sha256(pcm).hexdigest(),'minimum':min(floats),'maximum':max(floats),'rms':math.sqrt(sum(value*value for value in floats)/count),'pcm16_grid_exact':all(value*32768 == sample for value,sample in zip(floats,shorts)),'params':params,'registers':registers,'backtrace':[str(frame.GetThread().GetFrameAtIndex(i)) for i in range(min(12,frame.GetThread().GetNumFrames()))]}
        records.append(record)
        (ROOT / 'native-entry.json').write_text(json.dumps(records,indent=2))
        print('NATIVE_INPUT_CAPTURE index=' + str(index) + ' frames=' + str(count) + ' pcm16_sha=' + record['reconstructed_int16_sha256'])
        return False
    except Exception as error:
        (ROOT / 'capture-error.txt').write_text(repr(error))
        print('NATIVE_INPUT_CAPTURE_FAILED ' + repr(error))
        return True

def __lldb_init_module(debugger, internal_dict):
    breakpoint = debugger.GetSelectedTarget().BreakpointCreateByName('whisper_full')
    breakpoint.SetScriptCallbackFunction(__name__ + '.on_full')
    print('Native capture installed, breakpoint ' + str(breakpoint.GetID()))
