import AVFoundation
import CryptoKit
import Foundation
let dir = FileManager.default.temporaryDirectory.appendingPathComponent("retrace-aac-repeat-\(UUID())")
try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
var url = dir.appendingPathComponent(".encoding_123.m4a")
func sha(_ d:Data)->String { SHA256.hash(data:d).map{String(format:"%02x",$0)}.joined() }
func encode() throws {
 let format = AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:16000,channels:1,interleaved:false)!
 let buffer = AVAudioPCMBuffer(pcmFormat:format,frameCapacity:16000)!
 buffer.frameLength=16000
 for i in 0..<16000 { let phase=Double(i)/16000; let sample=Int16((sin(2 * .pi * 431 * phase) * 8000 + sin(2 * .pi * 719 * phase) * 3000).rounded()); buffer.floatChannelData![0][i]=Float(sample)/32768 }
 let settings:[String:Any]=[AVFormatIDKey:kAudioFormatMPEG4AAC,AVSampleRateKey:16000.0,AVNumberOfChannelsKey:1,AVEncoderAudioQualityKey:AVAudioQuality.medium.rawValue]
 let file=try AVAudioFile(forWriting:url,settings:settings,commonFormat:.pcmFormatFloat32,interleaved:false)
 try file.write(from:buffer)
}
func decode(_ format:AVAudioCommonFormat) throws -> Data {
 let file=try AVAudioFile(forReading:url,commonFormat:format,interleaved:true)
 let buffer=AVAudioPCMBuffer(pcmFormat:file.processingFormat,frameCapacity:4096)!
 var output=Data()
 var remaining=file.length
 while remaining>0 {
  try file.read(into:buffer,frameCount:AVAudioFrameCount(min(4096,remaining)))
  let count=Int(buffer.frameLength)
  if format == .pcmFormatInt16 { output.append(Data(bytes:buffer.int16ChannelData![0],count:count*2)) }
  else { output.append(Data(bytes:buffer.floatChannelData![0],count:count*4)) }
  remaining -= Int64(count)
 }
 return output
}
try encode()
let firstData=try decode(.pcmFormatInt16)
print("staged decode \(sha(firstData))")
let tracks=try await AVURLAsset(url:url).loadTracks(withMediaType:.audio)
let range=try await tracks[0].load(.timeRange)
print("native timing \(range.start.seconds) \(range.duration.seconds)")
let published=dir.appendingPathComponent("published.m4a")
try FileManager.default.linkItem(at:url,to:published)
try FileManager.default.removeItem(at:url)
url=published
for format in [AVAudioCommonFormat.pcmFormatInt16,.pcmFormatFloat32] {
 var previous:Data?
 for iteration in 1...5 {
  let data=try decode(format)
  let differing=previous.map { prior in zip(prior,data).filter{$0 != $1}.count } ?? 0
  print("format \(format.rawValue) iteration \(iteration) hash \(sha(data)) differingBytes \(differing)")
  previous=data
 }
}
try FileManager.default.removeItem(at:dir)
